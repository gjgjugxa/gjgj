module.exports = {
    publicPath: './',
}